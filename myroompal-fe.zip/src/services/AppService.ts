export default class AppService {

}