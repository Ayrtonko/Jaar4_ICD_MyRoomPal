export const config = {
    authDomain: "#{Auth0-domain}#",
    clientId: "#{Auth0-clientId}#",
    audience: "#{Auth0-audience}#",
    apiBaseUrl: "https://myroompal-#{environment}#-api.azurewebsites.net/api",
    // apiBaseUrl: "http://localhost:5147/api"
};