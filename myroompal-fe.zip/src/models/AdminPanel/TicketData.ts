export interface TicketData {
    id: number;
    issueType: string;
    description: string;
    status: string;
}
