export interface AdminUserSearchUser {
    id: number;
    name: string;
    email: string;
    phoneNumber: string;
    status: string;
}
