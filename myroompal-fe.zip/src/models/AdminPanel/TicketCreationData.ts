export interface TicketCreationData {
    issueType: string;
    description: string;
}
