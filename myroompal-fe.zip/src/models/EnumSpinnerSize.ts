enum EnumSpinnerSize {
    SM = 'sm',
    MD = 'md',
    LG = 'lg',
    XL = 'xl'
}

export default EnumSpinnerSize;
