export interface User {
  Occupation: string;
  SchoolOrCompany: string;
  ReligiousPreferences: string;
  DietaryPreferences: string;
  SmokingHabits: boolean; // Change from string to boolean
  SleepingHabits: string;
  SocialHabits: string;
  CleaningHabits: string;
}
