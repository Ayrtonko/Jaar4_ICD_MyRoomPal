type TPreferenceResponseType = {
    id: string,
    preferenceTag: string
}
export default TPreferenceResponseType