enum EnumUserStatus {
    BANNED = "Banned",
    UNBANNED = "Active",
}

export default EnumUserStatus;
