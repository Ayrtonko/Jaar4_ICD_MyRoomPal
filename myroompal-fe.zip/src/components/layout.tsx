import React from "react";
import Topnav from "./Topnav";


const Layout = () => {
    return (
        <>
            <Topnav />
        </>
    );
};  
