﻿namespace myroompal_api.Modules.MatchManagement.Models;

public class PreferenceVm
{
    public Guid Id { get; set; }
    public required string PreferenceTag { get; set; }
}