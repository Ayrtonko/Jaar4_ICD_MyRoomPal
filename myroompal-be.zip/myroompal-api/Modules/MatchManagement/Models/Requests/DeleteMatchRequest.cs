﻿namespace myroompal_api.Modules.MatchManagement.Models.Requests;

public class DeleteMatchRequest
{
    public Guid LikeeUserId { get; set; }
}