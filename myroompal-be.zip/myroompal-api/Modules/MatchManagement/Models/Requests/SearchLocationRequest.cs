﻿namespace myroompal_api.Modules.MatchManagement.Models.Requests;

public class SearchLocationRequest
{
    public required string SearchLocation { get; set; }
}