﻿namespace myroompal_api.Modules.MatchManagement.Models.Requests;

public class PreferenceUserRequest
{ 
    public required List<String> Preferences { get; set; }
}