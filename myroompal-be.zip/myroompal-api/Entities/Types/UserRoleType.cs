﻿namespace myroompal_api.Entities.Types;

public enum UserRoleType
{
    Tenant,
    Owner,
    Moderator
}