﻿namespace myroompal_api.Entities.Types;

public enum UserAccountStatusType
{
    Banned,
    Active
}