﻿namespace myroompal_api.Entities.Types;

public enum SupportTicketIssueType
{
    Login,
    Payment,
    Account,
    Renting,
    Other
}