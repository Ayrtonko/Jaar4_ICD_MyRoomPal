﻿namespace myroompal_api.Entities.Types;

public enum SupportTicketStatus
{
    New,
    Committed,
    Done
}